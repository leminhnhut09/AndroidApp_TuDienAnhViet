package com.minhnhut.tratudienanhviet.Models;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.LocaleDisplayNames;
import android.util.Log;
import android.widget.Toast;

import com.minhnhut.tratudienanhviet.MainActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class Utils {
    Context context;
    public Utils(Context context) {
        this.context = context;
    }


    public static  ArrayList<Word> lstLichSu = new ArrayList<>();
    public static  ArrayList<Word> lstTuVung = new ArrayList<>();
    public static  ArrayList<Irregular> lstIrregular = new ArrayList<>();
}
