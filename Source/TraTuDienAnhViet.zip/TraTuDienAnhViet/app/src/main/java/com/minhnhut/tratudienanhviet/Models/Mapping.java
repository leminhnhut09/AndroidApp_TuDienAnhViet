package com.minhnhut.tratudienanhviet.Models;

public class Mapping {

    public static int speed = 1;
    public static int accent = 1; // 1 : anh, 2 : my
    public static int isNotification = 0;
    //    default: Viet Nam
    public static String language = "VN";
}
